Roger Wang (rw794)

Homework A1 for NLP

chaos2json.py converts chaos.html to chaos.json

allpron.py adds "rhymeProns" to chaos.json and stores the file as chaos.pron.json

exact_rhymes.py does rhyme analysis on chaos.pron.json