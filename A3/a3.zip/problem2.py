import codecs
import numpy as np
from generate import GENERATE


vocab = codecs.open("brown_vocab_100.txt", "r", encoding="utf-16")

#load the indices dictionary
word_index_dict = {}
for i, line in enumerate(vocab):
    #TODO: import part 1 code to build dictionary

f = codecs.open("brown_100.txt", encoding = "utf-16")

counts = #TODO: initialize counts to a zero vector

#TODO: iterate through file and update counts

f.close()

#TODO: normalize and writeout counts. 



