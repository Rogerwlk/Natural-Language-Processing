import codecs


word_index_dict = {}

# TODO: read brown_vocab_100.txt into word_index_dict

# TODO: write word_index_dict to word_to_index_100.txt



print(word_index_dict['all'])
print(word_index_dict['resolution'])
print(len(word_index_dict))
